package com.myPack.smsapp.Dao;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.myPack.smsapp.Entity.Student;


public interface StudentDao extends JpaRepository<Student, Integer>{
	Optional<Student> findByStudentName(String studentName);
	
	Optional<Student> findByEmailIdAndStudentPassword(String email, String password);	//method to find student email and password
}
