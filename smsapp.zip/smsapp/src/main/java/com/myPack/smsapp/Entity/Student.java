package com.myPack.smsapp.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@SequenceGenerator(name = "generator1", sequenceName = "gen1", initialValue = 1)

public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generator1")    
    private Integer studentId;
	
	@NotEmpty
	@Size(min=2 , message="firstName must contain atleast 2 characters")
    private String studentName;
	
	@Column(name="email_id", unique = true, length = 30)
    @NotEmpty
    @Email(message = "Email is not valid")
    private String emailId;
	
	@NotEmpty
	@Size(min=8, message="Password length must be 8 and contain uppercase,lowercase,digits")
//	@Pattern(regexp="(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")
    private String studentPassword;
	
	@NotEmpty
	private String studentClass;
	
	@NotEmpty
	@Size(min=10 ,max=10, message="phoneNumber must contain  10 digits")
    private String studentContactNumber;
	
	@NotEmpty(message = "Address can not be empty")
    private String studentAddress;
	
	@NotEmpty(message = "Gender can not be empty")
    private String studentGender;

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	
	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public String getStudentClass() {
		return studentClass;
	}

	public void setStudentClass(String studentClass) {
		this.studentClass = studentClass;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getStudentContactNumber() {
		return studentContactNumber;
	}

	public void setStudentContactNumber(String studentContactNumber) {
		this.studentContactNumber = studentContactNumber;
	}

	public String getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", emailId=" + emailId
				+ ", studentPassword=" + studentPassword + ",studentClass=" + studentClass + ", studentContactNumber=" + studentContactNumber
				+ ", studentAddress=" + studentAddress + ", studentGender=" + studentGender + "]";
	}

	public Student(Integer studentId,
			@NotEmpty @Size(min = 2, message = "firstName must contain atleast 2 characters") String studentName,
			@NotEmpty @Email(message = "Email is not valid") String emailId,
			@NotEmpty @Size(min = 8, message = "Password length must be 8 and contain uppercase,lowercase,digits")String studentPassword,
			@NotEmpty String studentClass,
			@NotEmpty @Size(min = 10, max = 10, message = "phoneNumber must contain  10 digits") String studentContactNumber,
			@NotEmpty(message = "Address can not be empty") String studentAddress,
			@NotEmpty(message = "Gender can not be empty") String studentGender) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.emailId = emailId;
		this.studentPassword = studentPassword;
		this.studentClass = studentClass;
		this.studentContactNumber = studentContactNumber;
		this.studentAddress = studentAddress;
		this.studentGender = studentGender;
	}
	
	public Student(){
		super();
	}
	
}
