package com.myPack.smsapp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.myPack.smsapp.Dto.LoginRequest;
import com.myPack.smsapp.Entity.Student;
import com.myPack.smsapp.Service.StudentService;


@RestController
@CrossOrigin("http://localhost:4200")	//4200 is the front end port number
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	@PostMapping("/save/student")	//can give your own name //also called as endpoints
	public Student saveStudent(@RequestBody Student student) {
		return studentService.saveStudent(student);
	}
	
	@GetMapping("/get/student")
	public List<Student> getStudents(){
		return studentService.getStudents();
	}
	
	@GetMapping("/get/student/{studentId}")
	public Student getStudent(@PathVariable Integer studentId) {		//path variable is used to capture value from URL and put in code
		return studentService.getStudent(studentId);
	}
	
	@PutMapping("/update/student")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student) 
    {
		Student updatedStudent = studentService.updateStudent(student);
        if (updatedStudent != null) {
            return ResponseEntity.ok(updatedStudent);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
	
	@DeleteMapping("/delete/student/{studentId}")
	public void deleteStudent(@PathVariable Integer studentId) {
		studentService.deleteStudent(studentId);
	}
	
	// Endpoint to get Student by name
    @GetMapping("/name/{studentName}")
    public ResponseEntity<Student> getStudentByName(@PathVariable String studentName)
    {
    	Student student = studentService.getStudentByName(studentName);
        return ResponseEntity.ok(student);
    }
    
    //Endpoint for login
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginrequest){
		
    Student student;
		try {
			student = studentService.login(loginrequest.getEmailId(), loginrequest.getStudentPassword());
			return ResponseEntity.ok("Welcome, "+student.getStudentName());
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
		}
    }
}
