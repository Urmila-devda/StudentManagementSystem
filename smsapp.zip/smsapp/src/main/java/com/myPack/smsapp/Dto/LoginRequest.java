package com.myPack.smsapp.Dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

public class LoginRequest {
	@NotEmpty(message = "cannot be Empty.")
	@Email(message = "Email is not Valid.")
	private String emailId;
	
	@NotEmpty(message = "Cannot be empty.")
	@Size(min=8, message = "must contail upper case, special character and anumber")
	private String studentPassword;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	
}
