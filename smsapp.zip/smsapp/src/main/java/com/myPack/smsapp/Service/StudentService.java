package com.myPack.smsapp.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myPack.smsapp.Dao.StudentDao;
import com.myPack.smsapp.Entity.Student;

@Service
public class StudentService {
	@Autowired
	StudentDao stuDao;
	
	//to insert a new record
	public Student saveStudent(Student student) {
		return stuDao.save(student);
	}
	
	//fetch all record
	public List<Student> getStudents(){
		List<Student> students = new ArrayList<Student>();
		stuDao.findAll().forEach(students::add);
		return students;	
	}
	
	public Student getStudent(Integer studentId) {
		return stuDao.findById(studentId).orElseThrow();
	}
	
	public void deleteStudent(Integer studentId) {
		stuDao.deleteById(studentId);
	}
	
	public Student updateStudent(Student saveStudent) {
		 stuDao.findById(saveStudent.getStudentId()).orElseThrow();
		 return stuDao.save(saveStudent);
	}
	
	// Search student by name
    public Student getStudentByName(String studentName) {
        return stuDao.findByStudentName(studentName)
                .orElseThrow(() -> new RuntimeException("Student not found with name: " + studentName));
    }
    
    //method for login
    public Student login(String emailId, String password) {
    	return stuDao.findByEmailIdAndStudentPassword(emailId, password).orElseThrow(()->new RuntimeException("Invalid email or password"));
    }
}
