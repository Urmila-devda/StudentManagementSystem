import { Component, OnInit} from '@angular/core';
import { StudentService } from '../student.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: false,
  
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit{
  totalStudents: number = 0;

  constructor(private studentService: StudentService, private router: Router) {}

  ngOnInit(): void {
    this.getTotalStudents();
    this.updateEventStatuses();
  }

  getTotalStudents(): void {
    this.studentService.getStudents().subscribe(
      (data: any[]) => {
        this.totalStudents = data.length; // Count the number of students
      },
      (error) => {
        console.error('Error fetching students', error);
      }
    );
  } 

  // upcomingEvents = [
  //   { name: 'Parent-Teacher Meeting', date: '20th Dec' },
  //   { name: 'Sports Day', date: '25th Dec' },
  //   { name: 'Science Fair', date: '30th Dec' } // Add more events as needed
  // ];

  upcomingEvents = [
    { name: 'Parent-Teacher Meeting', date: '20th Dec', status: 'upcoming' },
    { name: 'Sports Day', date: '25th Dec', status: 'upcoming' },
    { name: 'Science Fair', date: '30th Dec', status: 'upcoming' }
  ];

  newEventName = '';
  newEventDate = '';

// addEvent() {
//   if (this.newEventName && this.newEventDate) {
//     this.upcomingEvents.push({ name: this.newEventName, date: this.newEventDate });
//     this.newEventName = '';
//     this.newEventDate = '';
//   }
// }

removeEvent(index: number) {
  this.upcomingEvents.splice(index, 1);
}

addEvent() {
  if (this.newEventName && this.newEventDate) {
    const newEvent = {
      name: this.newEventName,
      date: this.newEventDate,
      status: 'upcoming' // New events are by default "upcoming"
    };
    this.upcomingEvents.push(newEvent);
    this.sortEventsByDate(); // Sort events after adding a new one
    this.newEventName = '';
    this.newEventDate = '';
  }
}

// Update event statuses
updateEventStatuses() {
  const today = new Date();
  this.upcomingEvents.forEach(event => {
    const eventDate = this.convertToDate(event.date);
    if (eventDate < today) {
      event.status = 'done'; // Mark as done if the event date has passed
    } else {
      event.status = 'upcoming'; // Ensure future events are marked as upcoming
    }
  });
  this.sortEventsByDate(); 
}

//Sort events By date
sortEventsByDate() {
  this.upcomingEvents.sort((a, b) => {
    const dateA = this.convertToDate(a.date);
    const dateB = this.convertToDate(b.date);
    return dateA.getTime() - dateB.getTime();
  });
}

// Convert a date string like '20th Dec' to a Date object
convertToDate(dateString: string): Date {
  const currentYear = new Date().getFullYear(); // Get the current year
  const cleanedDateString = dateString.replace(/(st|nd|rd|th)/g, ''); // Remove ordinal suffixes
  return new Date(`${cleanedDateString} ${currentYear}`);
}

}
