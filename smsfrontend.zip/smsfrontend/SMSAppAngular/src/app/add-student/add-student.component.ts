import { Component } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';
import Swal from 'sweetalert2';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-add-student',
  standalone: false,
  
  templateUrl: './add-student.component.html',
  styleUrl: './add-student.component.css'
})
export class AddStudentComponent {
  student: Student = {
    studentId: 0,
    studentName: '',
    emailId: '',
    studentPassword: '',
    studentClass :'',
    studentContactNumber: '',
    studentAddress: '',
    studentGender: '',
  };

  constructor(private studentService: StudentService) {}

  //  Method to handle form submission
    onSubmit(form: NgForm) {
    if (form.valid) {
      this.studentService.saveStudent(this.student).subscribe(
        (response) => {
          // console.log('Student saved successfully:', response);
              // Display a success popup
          Swal.fire({
            title: 'Success!',
            text: 'Student saved successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
          });
          form.reset();
        },
        (error) => {
          // console.error('Error saving student:', error);
            // Display an error popup
            Swal.fire({
              title: 'Error!',
              text: 'There was a problem saving the student. Please try again later.',
              icon: 'error',
              confirmButtonText: 'OK'
            });
        }
      );
    }
  }
}
