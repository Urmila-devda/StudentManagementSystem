import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private baseUrl = 'http://localhost:8070'; // Spring Boot backend URL

  constructor(private http: HttpClient) {}

  saveStudent(student: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/save/student`, student);
  }

  getStudents(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/get/student`);
  }

  deleteStudent(studentId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/delete/student/${studentId}`);
  }

  updateStudent(student: any): Observable<any> {
    const url = `${this.baseUrl}/update/student`;
    return this.http.put<any>(url, student);
  }
}
