export interface Student {
  studentId: number;
  studentName: string;
  emailId: string;
  studentPassword: string;
  studentContactNumber: string;
  studentAddress: string;
  studentGender: string;
  studentClass: string;
//   studentSkills: string;
}
