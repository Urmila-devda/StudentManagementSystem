import { Component } from '@angular/core';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginObj: any = {
    username:'',
    password:''
  };

  // router = inject(Router);
  constructor(private router: Router) {}

  
  onLogin() {
    if(this.loginObj.username == "admin" && this.loginObj.password =="112233") {
      Swal.fire({
        title: 'Login Successful!',
        text: 'Welcome to the SMSAPP',
        icon: 'success',
        confirmButtonText: 'OK'
      });
      this.router.navigateByUrl('dashboard')
    } else {
      Swal.fire({
        title: 'Invalid!',
        text: 'Invalid login credential.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      // alert("Wrong Credentials")
    }
  }
  
}
