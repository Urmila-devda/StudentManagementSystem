import { Component ,OnInit} from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-view-student',
  standalone: false,
  
  templateUrl: './view-student.component.html',
  styleUrls: ['./view-student.component.css']
})
export class ViewStudentComponent implements OnInit{
  students: any[] = [];
  filteredStudents: any[] = [];
  searchQuery: string = '';
  searchFilter: string = 'id'; // Default filter is by ID
  isEdit: boolean = false; // Tracks whether the form is in edit mode
  selectedStudent: any = {};

  constructor(private studentService: StudentService) {}

  ngOnInit(): void {
    this.getStudents();
  }

  getStudents(): void {
    this.studentService.getStudents().subscribe(
      (data: any[]) => {
        this.students = data;
        this.filteredStudents = [...this.students]; // Initialize filteredStudents with all students
      },
      (error) => {
        console.error('Error fetching student data', error);
      }
    );
  }

  
  searchStudent(): void {
    if (!this.searchQuery.trim()) {
      this.resetSearch(); // If search query is empty, reset to show all students
      return;
    }

    if (this.searchFilter === 'id') {
      this.filteredStudents = this.students.filter(stu =>
        stu.studentId.toString().includes(this.searchQuery.trim())
      );
    } else if (this.searchFilter === 'name') {
      this.filteredStudents = this.students.filter(stu =>
        stu.studentName.toLowerCase().includes(this.searchQuery.trim().toLowerCase())
      );
    }
    else if (this.searchFilter === 'class') {
      this.filteredStudents = this.students.filter(stu =>
        stu.studentClass.toString().includes(this.searchQuery.trim())
      );
    }
  }

  resetSearch(): void{
    this.searchQuery = '';
    this.filteredStudents = [...this.students];
  }


  deleteStudent(studentId: number): void {
    if (confirm('Are you sure you want to delete this student?')) {
      this.studentService.deleteStudent(studentId).subscribe(
        () => {
          this.students = this.students.filter(stu => stu.studentId !== studentId);
          this.filteredStudents = [...this.students];
          alert('Student deleted successfully');
        },
        (error) => {
          console.error('Error deleting student', error);
          alert('Failed to delete student. Please try again.');
        }
      );
    }
  }

  onEdit(student: any): void {
    this.isEdit = true;
    this.selectedStudent = { ...student }; // Clone the selected student to avoid direct binding
  }

  saveStudent(): void {
    if (this.isEdit) {
      this.studentService.updateStudent(this.selectedStudent).subscribe(
        (updatedStudent) => {
          // Update the local student list with the new data
          const index = this.students.findIndex(
            stu => stu.studentId === updatedStudent.studentId
          );
          if (index !== -1) {
            this.students[index] = updatedStudent; // Replace with updated data
          }
          this.filteredStudents = [...this.students]; // Update filteredStudents
          this.isEdit = false; // Exit edit mode
          alert('Student updated successfully');
        },
        (error) => {
          console.error('Error updating student', error);
          alert('Failed to update student. Please try again.');
        }
      );
    }
  }

  
}
