import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ViewStudentComponent } from './view-student/view-student.component';
import { LoginComponent } from './login/login.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { DashboardComponent } from './dashboard/dashboard.component';
const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'viewStudent', component: ViewStudentComponent },
  {path: 'dashboard' , component: DashboardComponent},
  // { path: 'about', component: AboutComponent },
  // { path: 'contact', component: ContactComponent },
  { path: 'login', component: LoginComponent },
  // { path: 'signup', component: SignupComponent },
  { path: 'addStudent', component: AddStudentComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' }, //Default Route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
